/**
 * Escreva um programa que calcula a area de uma circunferencia
 *
 * Data:28/10/2021
 */
package numero9;

/**
 *
 * @author Fernando Gomes
 */
public class Numero9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //declaracao de variaveis
    }
    
}
