/**
 * 2 - Declarar as seguintes variaveis
 * a) soma, tipo int (inteiro) inicializado com zero
 * b) beta, tipo long (inteiro longo) inicializado com 1000000
 * c) raiz, tipo double (real) inicializado com 3.4
 * d) choose, tipo boolean inicializado com false
 */
package numero2;

/**
 *
 * @author Fernando Gomes
 */
public class Numero2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int soma = 0;
        long beta = 1000000;
        double raiz = 3.4;
        boolean choose = false;
    }
    
}
