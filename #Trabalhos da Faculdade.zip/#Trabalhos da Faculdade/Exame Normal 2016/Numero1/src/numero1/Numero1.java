
package numero1;

/**
 *
 * @author Fernando Gomes
 */
public class Numero1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int x = 0, y = 0, z = 0;
       
       //A
       //Math.abs(x-y/z);
       
       //b
       //Math.sqrt(x-1+x*y);
       
       //c
       System.out.println(Math.exp(1));
    }
    
}
