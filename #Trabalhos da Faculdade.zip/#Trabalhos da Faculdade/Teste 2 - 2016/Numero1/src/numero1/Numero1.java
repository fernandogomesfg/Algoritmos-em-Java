
package numero1;

/**
 *
 * @author Fernando Gomes
 */
public class Numero1 {
    public static void manda(double t){
        double d = 4000;
        double a = d*t/100;
        d = d + a;
        System.out.println(d);
    }
    /*
    public static void manda2(){
        double d = 4000;
        double t = 10;
        double a = d*t/100;
        d = d + a;
        System.out.println(d);
    }
*/

    public static void main(String[] args) {
        //manda(10);
        //Saida 4400.0
       
    }
    
}
