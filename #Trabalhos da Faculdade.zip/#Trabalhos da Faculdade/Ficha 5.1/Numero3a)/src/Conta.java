/**
 * Para cada alínea do exercício numero 1, crie as suas respectivas classes
 * 
 * Data: 13/11/2021
 */

/**
 *
 * @author Fernando Gomes
 */
public class Conta {
    private int número;
    private int saldo;
    private String satuts;
    
    public boolean depósito(){
        
        
        return false;
        
    }
    
    public boolean levantamento(){
        
        
        
        return true;
    } 
    
}
