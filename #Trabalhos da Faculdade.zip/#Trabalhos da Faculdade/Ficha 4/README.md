# Ficha 4
<p>Resolucao dos exercicios 13, 14 e 15 </p>
