/**
 * Usando o formato do programa do exercicio 12, escreva um programa para imprimir as constantes PI e E da Matematica
 *
 * Data: 07/11/2021
 */
package numero14;

/**
 *
 * @author Fernando Gomes
 */
public class Numero14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Impressao das constantes PI e E da Matematica");
        System.out.println("Contante PI: " + Math.PI);
        System.out.println("Constante E: " + Math.E);
    }

}
