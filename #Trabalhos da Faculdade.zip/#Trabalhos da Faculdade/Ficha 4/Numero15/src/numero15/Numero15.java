/**
 * Escreva um programa para testar as seguintes instrucoes
 *
 * Data: 07/11/2021
 */
package numero15;

/**
 *
 * @author Fernando Gomes
 */
public class Numero15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Caracteres ASCII e Unicode
        System.out.println("Letra A(ASCII type):" +'B');
        System.out.println('\u0041');
    }
    
}
