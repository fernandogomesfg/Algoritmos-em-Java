
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Fernando Gomes
 */
public class Dados_da_Pauta {
        public void numero_nome(){
        try {
            //Lendo o ficheiro  contendo  os  resultados  de  frequência  
            FileInputStream arquivo = new FileInputStream("Pauta de Frequencia de AM.txt");
            InputStreamReader input = new InputStreamReader(arquivo);
            BufferedReader br = new BufferedReader(input);
            
            String linha;
            do {   
                linha = br.readLine();
                if (linha != null) {
                    if(linha.contains("1") || (linha.contains("2")));
                    System.out.println(linha);
                        
                    }
                
                
            } while (linha != null);
            
            
            FileOutputStream pauta = new FileOutputStream("PautaFinalAM.txt");
            PrintWriter pr = new PrintWriter(pauta);
            
            pr.close();
            pauta.close();
        } catch (Exception e) {
        }
        
    
    }
    
}
