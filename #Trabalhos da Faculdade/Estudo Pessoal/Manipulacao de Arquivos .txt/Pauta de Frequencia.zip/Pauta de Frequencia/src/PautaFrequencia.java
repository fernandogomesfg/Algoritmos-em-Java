
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class PautaFrequencia {

    public static void main(String[] args) {

        try {
            //Lendo o ficheiro  contendo  os  resultados  de  frequência  
            FileInputStream arquivo = new FileInputStream("Pauta de Frequencia de AM.txt");
            InputStreamReader input = new InputStreamReader(arquivo);
            BufferedReader br = new BufferedReader(input);

            //cada linha do ficheiro contendo  os  resultados  de  frequência  
            String linha = null;

            do {
                linha = br.readLine();

                if (linha != null) {
                    //Leitura dos dados e colocando em um array
                    if ((linha.contains("Disciplina:")) || (linha.contains("Ano lectivo:")) || (linha.contains("Semestre:")) || (linha.contains("Nome do Docente:"))) {
                        //Colocando os dados em um array
                        String[] dados = {linha};

                    }

                    //Assumindo que os numeros de estudantes iniciam com o ano de 
                    //ingresso do estudante (assuminos anos que iniciam com 1 e 2
                    if ((linha.startsWith("1")) || (linha.startsWith("2"))) {

                        //Variavel para armazenar as testes
                        String testes;
                        testes = (linha.substring(linha.length() - 17));
                        //System.out.println(testes);

                        String[] notas = testes.split("	");
                        System.out.println("\n");

                        double media = 0, teste1, teste2, teste3;
                        for (int i = 0; i < notas.length; i++) {
                            System.out.println("Nota " + (i + 1) + ": " + notas[i]);

                            teste1 = Double.parseDouble(notas[0]);
                            teste2 = Double.parseDouble(notas[1]);
                            teste3 = Double.parseDouble(notas[2]);

                            //Calculo da media
                            media = (0.4 * ((teste1 + teste2) / 2) + (teste3 * 0.6));

                        }

                        //array de classificacao
                        String[] classificacao = {"Excluido", "Admitido", "Dispensado"};

                        //impressao da media
                        System.out.println("Media: " + media);

                        //Calculo da classificacao
                        if (media < 10) {
                            System.out.println(classificacao[0]);
                        } else if (media >= 10 && media < 14) {
                            System.out.println(classificacao[1]);
                        } else {
                            System.out.println(classificacao[2]);
                        }

                        //Impressao Pauta
                        FileOutputStream pauta = new FileOutputStream("PautaFinalAM.txt");
                        PrintWriter pr = new PrintWriter(pauta);

                        pr.println("UNIVERSIDADE EDUARDO MONDLANE\n"
                                + "FACULDADE DE CIENCIAS\n"
                                + "DEPARTAMENTO DE MATEMATICA E INFORMATICA\n"
                                + "\n"
                                + "Disciplina: Análise  Matemática\n"
                                + "Ano lectivo: 2021\n"
                                + "Semestre: Segundo Semestre\n"
                                + "Nome do Docente: Jose Joao\n"
                                + "\n"
                                + "Pauta final de Analise Matematica");
                        
                        //Elaboracao da pauta final
                        //deve estar
                        pr.close();
                        pauta.close();
                        
                        //Quantidade de alunos excluidos, admitidos dispensados 
                        //deve estar aqui
                        

                    }
                }

            } while (linha != null);
        } catch (Exception e) {
            System.out.println("ERRo");
        }

    }

}
